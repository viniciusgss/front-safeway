'use client';

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaMapMarkedAlt, FaRoute, FaSpinner, FaExclamationTriangle } from 'react-icons/fa';

// Importações do Leaflet
import { MapContainer, TileLayer, Marker, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

// Correção para ícones do Leaflet no React
import L from 'leaflet';
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';

// Configuração dos ícones
const DefaultIcon = L.icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// **ATENÇÃO:** Substitua esta URL pela URL de deploy da sua API (ex: https://sua-api-aqui.onrender.com)
const API_BASE_URL = 'http://127.0.0.1:8000'; 

// Estrutura de dados para o formulário de rotas
const initialRouteData = {
  origem: '',
  destino: '',
  condicao_metereologica: 'Sol', // Exemplo de valor padrão
  peso_risco: 50,
};

// Componente auxiliar para ajustar a visualização do mapa
const MapViewUpdater = ({ routes }) => {
  const map = useMap();
  
  useEffect(() => {
    if (routes && routes.length > 0) {
      const firstRoute = routes[0];
      // A API retorna [longitude, latitude] para as coordenadas da rota, mas o Leaflet espera [latitude, longitude]
      // A correção foi feita na fase anterior, mas estou mantendo a estrutura para garantir a compatibilidade
      const coordinates = firstRoute.coordenadas.map(coord => [coord[1], coord[0]]);
      
      if (coordinates.length > 0) {
        // Calcula o limite (bounds) das coordenadas da rota
        const bounds = L.latLngBounds(coordinates);
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [routes, map]);

  return null;
};


// Componente de Mapa com a visualização real
const MapDisplay = ({ routes, origin, destination }) => {
  if (!routes || routes.length === 0) {
    return (
      <div className="h-96 bg-[#0B0F1A] flex items-center justify-center rounded-lg text-gray-500 border border-purple-500/20">
        <FaMapMarkedAlt className="text-4xl mr-2" /> Insira a origem e o destino para calcular a rota.
      </div>
    );
  }

  const firstRoute = routes[0];
  // A API retorna [longitude, latitude] para as coordenadas da rota, mas o Leaflet espera [latitude, longitude]
  const polylinePositions = firstRoute.coordenadas.map(coord => [coord[1], coord[0]]);
  
  // Coordenadas de origem e destino para os marcadores
  const originPos = [origin.latitude, origin.longitude];
  const destinationPos = [destination.latitude, destination.longitude];
  
  // O Leaflet precisa de uma posição inicial, usamos a origem
  const initialCenter = originPos;

  return (
    <div className="h-96 w-full relative">
      <MapContainer 
        center={initialCenter} 
        zoom={10} 
        scrollWheelZoom={true} 
        className="h-full w-full rounded-lg border border-purple-500/20"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {/* Marcador de Origem */}
        <Marker position={originPos} title="Origem" />
        
        {/* Marcador de Destino */}
        <Marker position={destinationPos} title="Destino" />

        {/* Desenha a Rota - Cor de destaque roxo/rosa */}
        <Polyline positions={polylinePositions} color="#D946EF" weight={5} opacity={0.8} />
        
        {/* Ajusta a visualização do mapa para mostrar toda a rota */}
        <MapViewUpdater routes={routes} />
        
      </MapContainer>
      
      {/* Resumo da Rota sobreposto ao mapa */}
      <div className="absolute bottom-0 left-0 z-[1000] p-4 bg-[#1a1f3a]/90 m-4 rounded-lg shadow-xl max-w-xs border border-purple-500/20">
        <p className="font-semibold text-purple-400">Rota Calculada:</p>
        {routes.map((route, index) => (
          <div key={index} className="mt-2 p-3 border border-pink-400/50 rounded-lg bg-[#2d1b4e]/50 text-sm text-gray-300">
            <p className="font-bold text-pink-400">{route.resumo || `Rota ${index + 1}`}</p>
            <p>Distância: <span className="font-mono text-purple-300">{route.distancia_km.toFixed(2)}</span> km</p>
            <p>Tempo Estimado: <span className="font-mono text-purple-300">{route.tempo_min.toFixed(2)}</span> min</p>
            <p>Risco Médio: <span className="font-mono text-purple-300">{route.risco_medio.toFixed(2)}</span></p>
            <p>Custo Ajustado: <span className="font-mono text-purple-300">{route.custo_ajustado.toFixed(2)}</span></p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function RouteMapComponent() {
  const [formData, setFormData] = useState(initialRouteData);
  const [routeResult, setRouteResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'peso_risco' ? parseInt(value, 10) : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setRouteResult(null);
    setError(null);

    try {
      const apiEndpoint = `${API_BASE_URL}/routes/calculate`;
      const res = await axios.post(apiEndpoint, formData);
      
      if (res.data.sucesso) {
        setRouteResult(res.data);
      } else {
        setError(res.data.mensagem || 'Erro desconhecido ao calcular a rota.');
      }
    } catch (err) {
      console.error('Erro na chamada de Rotas:', err);
      setError(err.response?.data?.detail || 'Erro de conexão com a API. Verifique a URL base.');
    } finally {
      setLoading(false);
    }
  };

  return (
    // Estilo da Box: Fundo escuro, borda roxa/rosa, sombra
    <div className="p-6 bg-gradient-to-br from-[#1a1f3a] to-[#2d1b4e] rounded-xl shadow-lg border border-purple-500/20">
      <h2 className="text-2xl font-bold text-purple-400 mb-6 flex items-center">
        <FaRoute className="mr-2 text-pink-400" /> Cálculo de Rotas Otimizadas
      </h2>

      {/* Formulário de Cálculo de Rota */}
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <input
          type="text"
          name="origem"
          value={formData.origem}
          onChange={handleChange}
          placeholder="Origem (Ex: Campinas, SP)"
          // Estilo do Input: Fundo escuro, borda roxa/rosa
          className="p-3 bg-[#1a1f3a] border border-purple-500/30 text-gray-300 rounded-lg focus:ring-pink-400 focus:border-pink-400"
          required
        />
        <input
          type="text"
          name="destino"
          value={formData.destino}
          onChange={handleChange}
          placeholder="Destino (Ex: Rio de Janeiro, RJ)"
          // Estilo do Input: Fundo escuro, borda roxa/rosa
          className="p-3 bg-[#1a1f3a] border border-purple-500/30 text-gray-300 rounded-lg focus:ring-pink-400 focus:border-pink-400"
          required
        />
        
        <select
          name="condicao_metereologica"
          value={formData.condicao_metereologica}
          onChange={handleChange}
          // Estilo do Select: Fundo escuro, borda roxa/rosa
          className="p-3 bg-[#1a1f3a] border border-purple-500/30 text-gray-300 rounded-lg focus:ring-pink-400 focus:border-pink-400"
        >
          <option value="Sol">Sol</option>
          <option value="Chuva">Chuva</option>
          <option value="Neblina">Neblina</option>
          {/* Adicione outras condições conforme sua API */}
        </select>

        <div className="flex items-center border border-purple-500/30 rounded-lg p-3 bg-[#1a1f3a]">
          <label htmlFor="peso_risco" className="text-sm text-gray-400 mr-2">Peso do Risco (0-100):</label>
          <input
            type="number"
            id="peso_risco"
            name="peso_risco"
            value={formData.peso_risco}
            onChange={handleChange}
            min="0"
            max="100"
            // Estilo do Input: Fundo escuro, texto claro
            className="w-full focus:outline-none bg-[#1a1f3a] text-gray-300"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          // Estilo do Botão: Gradiente roxo/rosa
          className="md:col-span-2 p-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition duration-200 disabled:bg-gray-600 flex items-center justify-center"
        >
          {loading ? (
            <>
              <FaSpinner className="animate-spin mr-2" /> Calculando...
            </>
          ) : (
            'Calcular Rota Otimizada'
          )}
        </button>
      </form>

      {/* Mensagem de Erro */}
      {error && (
        <div className="flex items-center p-4 mb-4 text-sm text-red-400 bg-red-900/30 rounded-lg border border-red-500/50">
          <FaExclamationTriangle className="mr-2" /> {error}
        </div>
      )}

      {/* Visualização do Mapa e Resultados */}
      <MapDisplay 
        routes={routeResult?.rotas} 
        origin={routeResult?.origem} 
        destination={routeResult?.destino} 
      />
    </div>
  );
}